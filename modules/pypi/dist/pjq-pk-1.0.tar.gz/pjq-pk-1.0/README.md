# pypi
> 《如何制作pip安装包》：https://blog.csdn.net/m0_38088359/article/details/83656872
> https://blog.csdn.net/fengmm521/article/details/79144407